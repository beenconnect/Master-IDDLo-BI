package routines;

public class ExtractSKU {

    /**
     * Extract: not return value, only print "hello" + message.
     * 
     * 
     * {talendTypes} String
     * 
     * {Category} User Defined
     * 
     * {@param} string("world") input: The string need to be printed.
     * 
     * {example} helloExemple("world") # hello world !.
     */
    public static String Extract(String str){
    	
    	StringBuffer s = new StringBuffer(); 
    	char c='-';
    	int flag=0;
    	for(int i=0;i<str.length();i++){
    		if(str.charAt(i)==c){
    			if(flag==0){
    				flag=1;
    			}
    			else
    				break;	
    		}
    		s.append(str.charAt(i));
    	}
    	 return s.toString();
    }
    /**
     * ExtractSKUCategory: not return value, only print "hello" + message.
     * 
     * 
     * {talendTypes} String
     * 
     * {Category} User Defined
     * 
     * {@param} string("world") input: The string need to be printed.
     * 
     * {example} helloExemple("world") # hello world !.
     */
    public static String ExtractSKUCategory(String str){
    	
    	StringBuffer s = new StringBuffer(); 
    	char c='-';
    	int flag=0;
    	for(int i=0;i<str.length();i++){
    		if(str.charAt(i)==c)
    			break;
    		s.append(str.charAt(i));
    	}
    	 return s.toString();
    }
}
